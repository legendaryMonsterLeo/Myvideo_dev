// INFO BEGIN
//
// User = 201910013025(����) 
// Group = JAVA 
// Problem = ���й滮 
// Language = JAVA 
// SubmitTime = 2019-09-15 16:39:01 
//
// INFO END

import java.text.DateFormatSymbols;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;


public class Main {
	public static void main(String ars[]) {
		Scanner scanner = new Scanner(System.in);
		int n, m, k;
		int M[] = new int[10010];
		int map[][] = new int[50004][2003];
		for (int i = 0; i < 50004; i++) {
			for (int j = 0; j < 2003; j++) {
				map[i][j] = -1;
			}
		}
		int flag[]=new int[2003];
		n = scanner.nextInt();
		m = scanner.nextInt();
		k = scanner.nextInt();
		for (int i = 0; i < m; i++) {
			M[i] = scanner.nextInt();
		}
		int sumValue = 0;
		for (int i = 0; i < n - 1; i++) {
			int x, y, value;
			x = scanner.nextInt();
			y = scanner.nextInt();
			value = scanner.nextInt();
			map[x][y] = value;
			map[y][x] = value;
			sumValue = sumValue + value;
		}
		if (n == m && m == k) {
			System.out.print(sumValue);
		} else {
			if (k == 2) {
				int ans = 10000000;
				for (int i = 0; i < m; i++) {
					for (int j = i + 1; j < m; j++) {
						if (i == 0 && map[M[i]][M[j]]!=-1) {
							ans = map[M[i]][M[j]];
						} else {
							if(map[M[i]][M[j]]!=-1)
							ans = Math.min(ans, map[M[i]][M[j]]);
						}
					}
				}
				System.out.print(ans);
			} else {
				System.out.print(sumValue);
			}
		}
	}

	public static int Count(int a,int b,int map[][]) {
		return 0;
	}
	public static void init(int flag[]){
		for(int i=0;i<flag.length;i++){
			flag[i]=0;
		}
	}
}
