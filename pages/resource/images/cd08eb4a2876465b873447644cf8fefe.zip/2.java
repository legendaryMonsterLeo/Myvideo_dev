// INFO BEGIN
//
// User = 201910013025(����) 
// Group = JAVA 
// Problem = С����ƻ�������� 
// Language = JAVA 
// SubmitTime = 2019-09-15 14:28:33 
//
// INFO END

import java.util.Scanner;

public class Main {
	public static void main(String args[]) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		int num;
		int flag[] = new int[1100];
		for (int i = 0; i < 1005; i++) {
			flag[i] = 0;
		}
		int m = 0;
		int down = 0;
		int sumCnt = 0;
		int groupdown = 0;
		for (int i = 1; i <= n; i++) {
			int cnt = 1;
			int minApple = 1000008;
			m = scanner.nextInt();
			int thisCnt = 0;
			for (int j = 1; j <= m; j++) {
				num = scanner.nextInt();
				if (j == 1) {
					thisCnt = num;
					minApple = num;
				}
				if (num > 0 && thisCnt!=num) {
					thisCnt = Math.min(thisCnt, num);
					cnt++;
					if (cnt == 2) {
						flag[i-1] = 1;
						down++;
					}
				}
				if (num <= 0) {
					thisCnt = thisCnt + num;
				}

			}
			sumCnt = sumCnt +thisCnt;
		}
		for(int i=0;i<n;i++){
			if(flag[i%n]==1 && flag[(i+1)%n]==1 && flag[(i+2)%n]==1){
				groupdown++;
			}
		}
		System.out.print(sumCnt+" "+down+" "+groupdown);
	}
}
