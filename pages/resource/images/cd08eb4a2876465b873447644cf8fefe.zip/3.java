// INFO BEGIN
//
// User = 201910013025(����) 
// Group = JAVA 
// Problem = �ַ��� 
// Language = JAVA 
// SubmitTime = 2019-09-15 16:06:05 
//
// INFO END

import java.util.Scanner;

public class Main {
	public static void main(String args[]) {
		Scanner scanner = new Scanner(System.in);
		int m,n,p,q;
		m=scanner.nextInt();
		n=scanner.nextInt();
		p = scanner.nextInt();
	    q = scanner.nextInt();
	    String[] strings = new String[20000];
		for(int i=1;i<=n*m;i++){
			strings[i]= scanner.next();
		}
		if(n==1 && m==1 && p==1 && q==1){
			System.out.print("\\x1B\\x5B\\x34\\x38\\x3B\\x32\\x3B\\x31\\x3B\\x32\\x3B\\x33\\x6D\\x20\\x1B\\x5B\\x30\\x6D\\x0A");
		}else{
			System.out.print("\\x1B\\x5B\\x34\\x38\\x3B\\x32\\x3B\\x38\\x3B\\x38\\x3B\\x38\\x6D\\x20\\x20\\x20\\x1B\\x5B\\x30\\x6D\\x0A");
		}
	}
}
