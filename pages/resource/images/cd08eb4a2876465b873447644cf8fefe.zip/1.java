// INFO BEGIN
//
// User = 201910013025(����) 
// Group = JAVA 
// Problem = С����ƻ�� 
// Language = JAVA 
// SubmitTime = 2019-09-15 13:44:15 
//
// INFO END

import java.text.spi.NumberFormatProvider;
import java.util.Scanner;

public class Main {
	public static void main(String args[]){
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		int m = scanner.nextInt();
		int num[] = new int[1100];
		int sumCnt=0;
		int MaxCnt=0;
		int order=0;
		int Maxans=0;
		for(int i=1;i<=n;i++){
			MaxCnt=0;
			for(int j=0;j<=m;j++){
				num[j]=scanner.nextInt();
				if(j!=0){
					MaxCnt = MaxCnt-num[j];
				}
				sumCnt = sumCnt+num[j];
			}
			if(Maxans<MaxCnt){
				Maxans=MaxCnt;
				order=i;
			}
		}
		System.out.print(sumCnt+" "+order+" "+Maxans);
	}
}
